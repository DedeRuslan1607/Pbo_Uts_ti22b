import java.util.Scanner;

import service.MenuService;

public class App {

    static Scanner scanner = new Scanner(System.in);
    static Scanner scannerInt = new Scanner(System.in);

    public static void main(String[] args) throws Exception {

        MenuService menuService = new MenuService();
    }
}
